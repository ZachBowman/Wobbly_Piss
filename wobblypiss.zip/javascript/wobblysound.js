function play_sound (sound)
  {
  var s;
  
  if (sound == "great")
    {
    s = Math.floor (Math.random() * 2);
    if (s == 0) createjs.Sound.play ("sound_mmhmm1");
    else createjs.Sound.play ("sound_mmhmm2");
    }
  else if (sound == "good")
    {
    s = Math.floor (Math.random() * 3);
         if (s == 0) createjs.Sound.play ("sound_cough1");
    else if (s == 1) createjs.Sound.play ("sound_cough2");
    else createjs.Sound.play ("sound_hmm1");
    }
  if (sound == "good")
    {
    s = Math.floor (Math.random() * 3);
         if (s == 0) createjs.Sound.play ("sound_cough1");
    else if (s == 1) createjs.Sound.play ("sound_cough2");
    else createjs.Sound.play ("sound_hmm1");
    }
  if (sound == "ok")
    {
    s = Math.floor (Math.random() * 2);
    if (s == 0) createjs.Sound.play ("sound_ew1");
    else createjs.Sound.play ("sound_ew2");
    }
  if (sound == "bad")
    {
    s = Math.floor (Math.random() * 2);
    if (s == 0) createjs.Sound.play ("sound_uhoh1");
    else createjs.Sound.play ("sound_uhoh2");
    }
  else if (sound == "drop water")
    {
    s = Math.floor ((Math.random() * 6) + 1);
         if (s == 1) createjs.Sound.play ("sound_water_hit1");
    else if (s == 2) createjs.Sound.play ("sound_water_hit2");
    else if (s == 3) createjs.Sound.play ("sound_water_hit3");
    else if (s == 4) createjs.Sound.play ("sound_water_hit4");
    else if (s == 5) createjs.Sound.play ("sound_water_hit5");
    else if (s == 6) createjs.Sound.play ("sound_water_hit6");
    }
  else if (sound == "drop floor")
    {
    s = Math.floor ((Math.random() * 6) + 1); 
         if (s == 1) createjs.Sound.play ("sound_floor_hit1");
    else if (s == 2) createjs.Sound.play ("sound_floor_hit2");
    else if (s == 3) createjs.Sound.play ("sound_floor_hit3");
    else if (s == 4) createjs.Sound.play ("sound_floor_hit4");
    else if (s == 5) createjs.Sound.play ("sound_floor_hit5");
    else if (s == 6) createjs.Sound.play ("sound_floor_hit6");
    }
  else if (sound == "glug")
    {
    createjs.Sound.play ("sound_glug2");
    }
  else if (sound == "explosion")
    {
    createjs.Sound.play ("sound_explosion");
    }
  else if (sound == "break toilet")
    {
    createjs.Sound.play ("sound_break_toilet");
    }
  else if (sound == "break wall")
    {
    createjs.Sound.play ("sound_break_wall");
    }
  else if (sound == "break floor")
    {
    createjs.Sound.play ("sound_break_floor");
    }
  else if (sound == "panic")
    {
    s = Math.floor (Math.random() * 3);
         if (s == 0) createjs.Sound.play ("sound_shit1");
    else if (s == 0) createjs.Sound.play ("sound_shit2");
    else createjs.Sound.play ("sound_shit3");
    }
  }
